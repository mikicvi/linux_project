#!/system/bin/sh

_PATH="$PATH"
export PATH="/system/bin:/system/xbin:/sbin"

BUSYBOX=""

if [ -x "/system/xbin/busybox" ]; then
        BUSYBOX="/system/xbin/busybox"
elif [ -x "/system/bin/busybox" ]; then
        BUSYBOX="/system/bin/busybox"
else
	BUSYBOX="/data/local/tmp/rootfix/busybox"
fi

echo ""
echo "============================================="
echo "=      STARTING ON DEVICE INSTALLATION!     ="
echo "============================================="
echo "=    NOTE: YOUR DEVICE SHOULD NOT REBOOT    ="
echo "=     UNTIL THE INSTALLER SAYS IT WILL!     ="
echo "============================================="
echo ""

echo "killing RIC, remount /system rw and temporarily disabling the RIC service..."

if [ -x "/sbin/ric" ]; then
	/data/local/tmp/rootfix/busybox mount -o remount,rw /
        chmod 644 /sbin/ric
	/data/local/tmp/rootfix/busybox pkill -f /sbin/ric
	/data/local/tmp/rootfix/busybox mount -o remount,rw /system
fi

if [ -x "/system/bin/ric" ]; then
	/data/local/tmp/rootfix/busybox pkill -f /system/bin/ric
	/data/local/tmp/rootfix/busybox mount -o remount,rw /system
        chmod 644 /system/bin/ric
	/data/local/tmp/rootfix/busybox pkill -f /system/bin/ric
fi

if [ "$BUSYBOX" = "" -o ! -x "$BUSYBOX" ]; then

	echo "No busybox found, copying busybox to system."
	cp /data/local/tmp/rootfix/busybox /system/xbin/
	chmod 755 /system/xbin/busybox

else

	# Lets check if it supports nohup
	echo "Found busybox, checking if it supports nohup..."
	NOHUP=`$BUSYBOX --list | $BUSYBOX grep nohup | $BUSYBOX wc -l`
	if [ $NOHUP -eq 0 ]; then

		# Removing existing one, this does not support nohup
		if [ -x "/system/xbin/busybox" ]; then
			/system/bin/toolbox rm -f /system/xbin/busybox
		fi
		if [ -x "/system/bin/busybox" ]; then
			/system/bin/toolbox rm -f /system/bin/busybox
		fi

		echo "It does not, copying a replacement busybox to system."
		rm -rf $BUSYBOX
		cp /data/local/tmp/rootfix/busybox /system/xbin/
		chmod 755 /system/xbin/busybox
		BUSYBOX="/system/xbin/busybox"

	else

		echo "It does, EXCELLENT! :)"

	fi

fi

DEVICE=`getprop ro.product.device`

if [ "$DEVICE" = "C1904" -o "$DEVICE" = "C1905" -o "$DEVICE" = "C2004" -o "$DEVICE" = "C2005" -o "$DEVICE" = "C2104" -o "$DEVICE" = "C2105" ]; then

	SEMCPROD=`getprop ro.semc.product.name`
	echo "$SEMCPROD found, installing install-recovery-2.sh instead..."

	$BUSYBOX rm -f /system/etc/install-recovery-2.sh
	$BUSYBOX cp /data/local/tmp/rootfix/install-recovery-2.sh /system/etc/
	$BUSYBOX cp /data/local/tmp/rootfix/install-recovery-2.sh /system/etc/install-recovery-2.sh
	$BUSYBOX chmod 755 /system/etc/install-recovery.sh
	$BUSYBOX chmod 755 /system/etc/install-recovery-2.sh

else

	echo "copying the rootfix files to /system/bin..."
	$BUSYBOX cp /data/local/tmp/rootfix/killric.sh /system/bin/
	$BUSYBOX rm -f /system/bin/ctrlaltdel
	$BUSYBOX cp /data/local/tmp/rootfix/ctrlaltdel /system/bin/
	$BUSYBOX chmod 755 /system/bin/killric.sh
	$BUSYBOX chmod 755 /system/bin/ctrlaltdel

fi

echo ""
echo "============================================="
echo "=        DONE WITH THE INSTALLATION!        ="
echo "=     NOTE: YOUR DEVICE WILL NOW REBOOT!    ="
echo "============================================="
echo ""

reboot
