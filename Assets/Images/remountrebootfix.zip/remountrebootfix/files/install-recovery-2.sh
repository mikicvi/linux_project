#!/system/bin/sh

pkill -f /sbin/ric; mount -o remount,rw /; chmod 644 /sbin/ric; mount -o remount,ro /

