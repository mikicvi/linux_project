#!/system/bin/sh

#####
#
# Check RIC looper, it will exit as soon as it found and killed it!
#
# Author: [NUT] from XDA
#

DoesFileExist() {
	if [ -f "/tmp/killedric" ]; then
		return 0
	else
		return 1
	fi
}

# As the init.rc scripts seem to be running parallel, lets kill ric if it got started.
until DoesFileExist
do

	RICCHECK=`$BUSYBOX ps | $BUSYBOX grep "/sbin/ric" | $BUSYBOX wc -l`

	if [ $RICCHECK -gt 1 ]; then

		$BUSYBOX pkill -f /sbin/ric

	fi

	if [ $RICCHECK -eq 1 ]; then

		$BUSYBOX touch /tmp/killedric

	fi

	$BUSYBOX sleep 2

done

exit 0
